package com.example.submission.abstraction

interface HasToolbar {
    fun setupToolbar()
}