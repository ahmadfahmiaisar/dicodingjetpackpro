package com.example.submission.data.vo

object Constant {
    const val DATABASE_NAME = "movie.db"
}